"""Author notebook JSON without executing numerical code locally."""
import json
from pathlib import Path

STAGES = [
    ("00_Campaign_Control", "contracts", "Validate the reproducible execution environment and numerical contracts."),
    ("01_Dataset_Audit", "audit", "Verify source bytes, EEG/EOG/label semantics, identities and exposure."),
    ("02_Contracts_and_Splits", "contracts", "Validate lag signs, finite boundaries, VMD parity, masks and metrics."),
    ("03_Controlled_Corpus", "corpus", "Freeze participant/donor/recipient roles and generate coherent mixtures."),
    ("04_Frontal_VMD_Search", "vmd", "Compare K=3..10 and five alpha values; VMD must add value beyond regression."),
    ("04a_VMD_Correction_Diagnosis", "vmd-diagnosis", "Inspect solver reconstruction, projection closure, mode gates and calibration baselines."),
    ("04b_VMD_SOBI_Comparison", "vmd-sobi", "Evaluate a paper-inspired mode-domain SOBI candidate with explicit EOG/entropy selection."),
    ("05_Posterior_Experts", "posterior", "Validate GEVD-MWF and ICA with raw frontal support on unscored calibration."),
    ("06_Regional_Comparison", "regional", "Compare disjoint regional correction, shared processing and context ablations."),
    ("07_Approach_Review", "review", "Review all candidates and preservation; authorize models only on passing gates."),
    ("07a_Paper_Metric_Contracts", "paper-fixture", "Validate source-mapped equations before any formal paper evaluation."),
    ("07b_Native_Paper_Protocol", "native-protocol", "Evaluate complete native conditions and an explicitly adapted eight-second chance analysis."),
    ("08_Teacher_Crossfit", "teacher-oof", "After passing gates, generate source-isolated teacher targets."),
    ("09_EEG_Only_Student", "student-paired", "After passing gates, train one EEG-only baseline."),
    ("10_Distillation_Ablations", "student-distill", "Evaluate teacher supervision and declared loss/architecture additions."),
    ("11_Model_Freeze", "freeze", "Freeze development-selected weights and analysis before confirmation access."),
    ("12_Reserved_Evaluation", "final-eval", "Evaluate untouched sources with the frozen cleaner; native data have no paired SNR."),
    ("13_Export_and_Report", "export", "Verify fresh-process deployment and assemble reproducible research evidence.")
]

DETAILS = {
    "vmd-sobi": "Required parents: completed corpus and VMD search. Reuse archived K/alpha vectors; whiten their mode matrix and jointly diagonalize symmetric delayed covariances. Two declared delay banks, positive convergence/rank checks and failed-fit pass-through are explicit adaptations. Compare selected-source subtraction, source reference projection and approximate-entropy-plus-EOG selection. Retain the original residual and source means; all artifacts are relative to raw EEG. A 12-example pilot must pass before the 128-example mechanism comparison. The paper's SVM/GA pipeline is not claimed replicated; this experiment cannot select a teacher or authorize models. See docs/VMD_SOBI_PLAN.md.",
    "vmd-diagnosis": "Required parents: completed corpus and VMD search. Reuse immutable selected-mode vectors; do not refit or overwrite the search. Compare exact mode-plus-residual reconstruction and linear projection closure against matched direct regression. Isolate discarded mode projections, residual projection and convergence pass-through; show declared-threshold ablations without choosing a new teacher. Partition recovery MSE into squared mean bias and centered variance; centered-only SNR is never an acceptance metric. Test an explicit unscored EOG calibration baseline as an experimental alternative to zero-mean scoring projection. Clean targets and true artifact are diagnostic-only; no target enters the correction. This Fz-focused mechanism study cannot authorize a final teacher or model.",
    "native-protocol": "Required parents: completed corpus, VMD and posterior kernels plus the original source bundle. Reuse frozen development-only calibration/scoring trial IDs and held-out-fold recipes. Correct complete trials with aligned reference windows and one overlap-add subtraction. Match author-code condition concatenation for per-channel rest RMSE and ordinary Pearson, retaining signed and absolute results. Prefer verified publisher HEOG_lpf/VEOG_lpf; disclose raw fallback. Welch segments never cross trial joins. Bootstrap five distinct verified participants and eight-second rest/ocular banks for 5,000 draws; whole-montage averaging and non-overlapping bank sampling are declared adaptations, not exact paper-region replication or equivalence. See docs/NATIVE_PROTOCOL_PLAN.md. A two-record pilot must pass before the full job.",
    "paper-fixture": "Validate IVMD-SOBI RRMSE/MSE and the disclosed printed CC discrepancy, ordinary condition-specific EEG-EOG Pearson from EEGOAR-Net/Kobler, rest RMSE, Welch 2-second/1-second overlap with the paper's bands, explicit PSNR scaling and participant-level paired permutation. Read docs/EVALUATION_PROTOCOL.md for exact source locations and adaptations. SNR output, SNR improvement, PSNR and linear input RMS ratio are separate quantities. No synthetic fixture or old project-only gate can authorize models.",
    "classical-fixture":"Bounded synthetic software integration on Kaggle: generate five synthetic source buckets, execute reduced VMD/posterior searches, regional matched ablations, OSF-style proxies, legacy-style paired scoring and the review gate. The reduced fixture grid is explicitly saved and cannot replace the forty-setting production search. Synthetic pilot results must never authorize neural development. All numerical contracts run first.",
    "source-fixture":"Focused Kaggle reproduction of raw LEMON BrainVision archive loading. Verify original archive/header hashes and actual EEG/marker inventory. Resolve only a unique same-directory renamed companion, retain original header bytes and disclose the temporary loading-header changes. Never invent event annotations or modify EEG payloads. Validate one development participant before resuming the full corpus.",
    "contracts": "Validate exact lag sign/edges, signed per-channel reference association, unit-invariant VMD parity, residual retention, overlap-add, analytic GEVD operators and source reservation. Failures stop the campaign; old draft tests are not evidence for this run.",
    "audit": "Required inputs: checksummed private original bundle plus the study04 FDT supplement. Inspect original EEG/EOG/label types and global participant IDs, keep unknown Klados anatomy unknown, freeze 20% confirmation identities before windows. Development caches contain separate calibration and scoring trials. Magdeburg waveform access stays closed.",
    "corpus": "Required parent: completed audit kernel. Download raw development LEMON recordings, filter calibration/scoring independently at 200 Hz and 0.5â€“40 Hz. Retain low-ocular recipient references using a fixed recipient-calibration criterion. Build donor-calibrated lagged HEOG/VEOG spatial fields on exact-name montage intersections; save clean/blink/lateral/mixed conditions and -5/0/+5 dB input mixtures. Donors and recipients share a frozen crossfit bucket so either identity remains excluded together. Native OSF and legacy Klados are separate cohorts.",
    "vmd": "Required parent: completed corpus kernel. RMS-normalized VMD searches K=3..10 and alpha=250/500/1000/2000/4000 with uniform initialization, tau=0, no forced DC, tolerance 1e-6 and cap 2000. Save u_k vectors [K,1024], residual, learned center frequencies, bandwidths, overlap, convergence and runtime. Compare whole-mode removal, selective joint-EOG projected correction and direct ridge under matched lag/penalty/strength/association grids. Five modes are not assumed to be five EEG bands. Parameter selection cannot inspect confirmation sources.",
    "posterior": "Required parent: completed corpus kernel. Fit regularized GEVD-MWF ranks 1..4, instantaneous/short-lag covariance and extended Picard ICA on unscored calibration only. Compare posterior-only, raw frontal support, full montage with posterior-only correction, and signed frontal summaries. Component reference selection uses calibration EOG. Estimate artifacts from the original scoring EEG and retain PCA residuals. Insufficient calibration/convergence failures score as passthrough. SGEYESUB is reported only if its original calibration implementation is qualified.",
    "regional": "Required parents: completed corpus, VMD search and posterior search kernels. For each held-out source bucket, select recipes using the other buckets. Frontal VMD, posterior ICA/MWF and shared-channel baseline all see the same original input; subtract disjoint corrections exactly once. Compare identity, direct regression, shared VMD and no-context variants. Report source-balanced blink/lateral/mixed SNR, clean modification, alpha/beta and covariance preservation, paired correlation and HEOG/VEOG proxies. Preserve all eligible failures.",
    "review": "Required parents: completed contracts, corpus, VMD, posterior and regional kernels. Inspect full search tables, center-frequency/vector figures, source-level uncertainty, failures and computational cost. The classical gate requires >=15 dB controlled development mean SNR, <=1% worst-source mean clean modification, <=0.5 dB alpha/beta error, <=0.02 covariance error and <=0.005 paired-correlation deterioration versus direct regression. A regional VMD hybrid must show benefit over matched regression. Only a passing archived gate permits neural implementation/training under the user's conditional authorization.",
    "teacher-oof": "Requires a passing classical_gate.json. Teacher configuration selection and global fits must exclude both recipient and donor identities for each target. HEOG/VEOG remain teacher-only information; save source identities and exclusion checks for every target.",
    "student-paired": "Requires a passing classical gate and verified source partitions. Start with paired-only EEG supervision before distillation. The approved candidate is a shared width-32 temporal encoder with five dilated blocks, BiGRU 32 units per direction and zero-initialized regional residual heads. EEG masks and verified metadata permit variable channel counts. HEOG/VEOG never enter the exported model. No training begins while the classical gate is closed.",
    "student-distill": "Requires approval evidence and a validated paired baseline. Evaluate train-only cross-fitted teacher supervision, spectral/covariance preservation, optional 20 dB shortfall loss, regional/shared and bounded architecture ablations. Development selection uses grouped sources and seeds 42/3407/2026. Do not select on reserved data.",
    "freeze": "Freeze one source SHA, checkpoint hash, inference gate and analysis configuration from grouped development evidence. Record the evidence snapshot before any confirmation waveform evaluation.",
    "final-eval": "Requires the frozen model/analysis artifacts. Open reserved controlled sources and independent real EEG exactly once. Controlled SNR is reconstruction against retained recipient references; real EEG without targets receives suppression/preservation proxies. Report failures and participant-level uncertainty without retuning.",
    "export": "Verify fresh-process CPU loading and whole-record overlap-add, channel masks, missing metadata/context and measured 10/20/30/40/50-channel scaling. Package reproducible inference, source/checkpoint hashes, achieved SNR and limitations. Offline BiGRU preprocessing is not a claim of causal real-time deployment."
}


NEW_STAGES = [
    ("41_Frontal_Gain_Adjusted_Event_Support", "frontal-event-gain-calibration", "Match event detector excursions to inferred EEG ocular strength without changing the VMD correction."),
    ("42_Native_Gain_Adjusted_Event_Support", "frontal-native-gain-events", "Validate eligible gain-adjusted support on native whole trials with original references."),
    ("43_Frontal_Monotonic_Axis_Events", "frontal-axis-events", "Separate blink and lateral detection using monotonic calibrated axis amplitude."),
    ("44_Native_Monotonic_Axis_Events", "frontal-native-axis-events", "Gated native validation of unscaled axis support."),
    ("45_Native_Scaled_Axis_Events", "frontal-native-scaled-axis-events", "Gated native validation of gain-adjusted monotonic axis support."),
    ("46_Frontal_Subspace_And_Window_Routing", "frontal-subspace-hybrid", "Bounded correction-strength and event-routing ablations at fixed K3/2000."),
    ("40_Native_Frontal_Event_Preservation", "frontal-native-events", "Test resting-calibration event restriction on whole native trials without scoring labels."),
    ("39_Frontal_Resting_Calibration_Event_Support", "frontal-event-calibration", "Restrict fixed frontal VMD correction using reference-only resting/ocular calibration event detection."),
    ("38_Frontal_Signed_Axis_Hybrid", "frontal-axis-calibration", "Compare separate signed ocular-axis gains with the fixed shared-gain frontal VMD hybrid."),
    ("37_Native_Frontal_Calibration_Hybrid", "frontal-native-calibration", "Validate fixed frontal calibration/VMD hybrids on complete native OSF trials."),
    ("36_Frontal_Calibration_VMD_Hybrid", "frontal-calibration-hybrid", "Test signed lagged calibration fields with matched raw versus frontal VMD gain estimation."),
    ("35_Frontal_Gain_Unit_Audit", "frontal-gain-unit-audit", "Test whether absolute model floors distort volt-scale frontal inputs."),
    ("34_Frontal_Hybrid_Result_Review", "frontal-hybrid-evidence", "Review immutable four-arm frontal hybrid results, paper metrics, preservation and uncertainty."),
    ("33_Frontal_Fixed_Gain_Hybrid", "frontal-gain-hybrid", "Test fixed K3 VMD gain hybrids with separate ocular-axis support and calibration mean anchoring."),
    ("32_Frontal_Frozen_Gain_Transfer", "frontal-frozen-transfer", "Transfer frozen historical VMD gains to verified frontal channels without new neural fitting."),
    ("30_Frontal_Cache_Audit", "frontal-cache-audit", "Diagnose fixed archived reconstruction failures without changing caches or running VMD."),
    ("24_Frontal_Contracts", "frontal-fixture", "Validate fixed-recipe frontal masks, reconstruction and reference boundaries."),
    ("25_Frontal_Replication_Comparison", "frontal-comparison", "Compare fixed frontal VMD corrections and declared paper adaptations without AutoVMD."),
    ("26_Frontal_Native_OSF", "frontal-native", "Validate fixed frontal recipes on complete OSF trials without posterior correction."),
    ("27_Frontal_Result_Inspection", "frontal-evidence", "Inspect frontal mode vectors, saved predictions, event support and lateral lag alignment."),
    ("28_Frontal_Correction_Screen", "frontal-comparison", "Select correction parameters within each fixed arm on source-excluded development subsets."),
    ("29_Frontal_Full_Evaluation", "frontal-evaluation", "Evaluate frozen frontal recipes on every eligible development recipient."),
    ("22_Posterior_Context", "posterior-context", "Matched ICA and GEVD-MWF posterior experts with raw and signed frontal support."),
    ("21_Neural_Preservation_Diagnosis", "neural-diagnosis", "Audit exact clean targets and saved neural distortion before expanding training."),
    ("14_Research_Readiness", "research-ready", "Verify restored OSF sources and all frozen development pairs."),
    ("15_Neural_Contracts", "neural-fixture", "Validate neural identity, masks, routing and optimization on Kaggle."),
    ("16_AutoVMD_Cache", "autovmd-cache", "Cache balanced all-frontal decompositions for all forty settings."),
    ("17_AutoVMD_Selection", "autovmd-search", "Nested development-only successive screening."),
    ("18_Regional_Router", "router-train", "Matched EEG-only regional and fixed-band neural experiments."),
    ("19_Paired_Deployment_Student", "student-paired", "Paired-only TCN-BiGRU deployment baseline.")
]
DETAILS.update({
    "frontal-event-gain-calibration": "Keep fixed K3/2000, shared calibration gains and unscaled event controls unchanged. Before event classification, scale EOG excursions around the resting calibration center by the already estimated shared EEG ocular-field gain. Controlled mixtures scale EEG artifacts without changing donor EOG arrays; reference-only amplitude gating otherwise ignores their transfer strength. This fixed adaptation changes detector inputs only, preserves original HEOG/VEOG for evaluation and uses no scoring condition or target. Record support/gain decisions, all failures, paper metrics and unchanged engineering gates. No gain-cap search, AutoVMD, posterior VMD or new neural weights.",
    "frontal-native-gain-events": "Requires completed gain-adjusted controlled parent and passing scaled-event and shared-control gates. Reuse fixed detector and correction on native calibration/scoring trial boundaries; no native retuning. Preserve publisher evaluation EOG references. Retain resting modification, alpha/beta and covariance gates, pass-through failures, whole-trial outputs and original ungated/event controls. Failed controlled parents stop execution before scoring.",
    "frontal-axis-events": "Use the same K3/2000 signed calibrated correction and matched raw control. Fit separate HEOG and VEOG STD/95th amplitude thresholds above all whole resting calibration windows. OR axis evidence; do not use scored conditions or targets. Compare raw-reference and gain-adjusted monotonic support against unchanged ungated correction. Unlike pooled logistic support, amplitude amplification cannot suppress an event. Thresholds remain fixed without performance-based retuning. Report original paper metrics and engineering gates, failures, units, axes and support decisions.",
    "frontal-native-axis-events": "Requires completed monotonic detector parent and passing controlled unscaled event arms. Reuse the exact separate-axis detector, calibration trials, correction and K3/2000 with original publisher evaluation EOG. Preserve complete-trial outputs, resting preservation checks and failure counts. No native retuning or reconstruction SNR claim.",
    "frontal-native-scaled-axis-events": "Requires completed monotonic detector parent and passing controlled gain-adjusted event arms. Use gain-adjusted support from the same separate-axis detector with unchanged frontal correction. Native rest gates and all data/source identities remain unchanged. Preserve failed arms and original EOG evaluation references; never qualify a model from a successful software test alone.",
    "frontal-subspace-hybrid": "Keep unchanged calibrated raw/VMD, monotonic temporal event and gain-adjusted controls. Compare complete-window correction conditional on any calibrated axis event. A separate VMD extension projects the predicted calibration field into the selected-mode span before gain estimation, so numerator and denominator use the same representation. Retain the original full-band artifact field for subtraction once. Compare subspace gain with and without whole-window routing. No clean targets in inference, no new neural fitting, no K/alpha search or relaxed gates. These are project adaptations, not exact paper reproductions.",
    "frontal-native-events": "Requires controlled event arms to pass the unchanged full-coverage accuracy and preservation gates. Compare the previous shared-gain controls with event-restricted raw and K3/VMD correction on complete native OSF trials. Each record fits reference-only event support using its unscored calibration labels; scored trial labels enter evaluation only. Save every trial prediction and decision, record recovery, original evaluation references and resting preservation. This is a development-exposed diagnostic following a failed native preservation result, not independent qualification or a new SNR estimate. Posterior integration remains blocked until preservation is reviewed.",
    "frontal-event-calibration": "Unchanged fixed K3/2000 shared field-gain controls plus event-restricted raw and VMD arms. Fit a reference-only logistic detector on each unscored calibration recording using trial labels (rest versus ocular), 256-sample windows and 128-sample hop without crossing trial joins. Use resting-calibrated amplitude/peak/velocity features and a threshold exceeding both all calibration-rest logits and probability 0.9. Expand support 100 ms with tapered edges, then multiply the artifact estimate, never the EEG. The scored condition and clean target cannot enter inference. Ineligible calibrations are visible scored pass-through. This predeclared extension addresses the failed native resting-preservation diagnostic; it may sacrifice suppression and is not qualified until controlled and native comparisons pass. No AutoVMD, posterior VMD or new neural weights.",
    "frontal-axis-calibration": "Fixed K3/2000 extension with no K/alpha selection or model fitting. Keep the matched calibration shared-gain arms unchanged. Split the lag-major calibrated field into signed HEOG and VEOG contributions, then fit two montage-wide gains from selected VMD modes or raw frontal input, using RMS normalization and ridge 0.01 with bounds [0,8]. The common intervention threshold remains 0.4 and mode association 0.2. Subtract only the estimated field from original EEG once, retain residuals and pass-through failed modes. Evaluate all 320 development examples, clean gates and matched raw-axis control; no native retuning, posterior VMD or reserved sources. This is a predeclared mechanistic comparison, not proof of superiority.",
    "frontal-native-calibration": "Requires the completed 320-example calibration hybrid with both raw and K3/VMD arms passing all controlled gates. Verify every development SET/FDT before the two-record pilot; consume declared unscored calibration only. Reuse K3/2000 and fixed lag/threshold/ridge/gain bounds without native retuning. Compare identity, fixed lagged direct regression, calibrated raw gain and calibrated VMD gain on whole trials using overlap-add. Retain unchanged published evaluation references; report HEOG lateral and VEOG blink/vertical correlations, resting RMSE/spectra/covariance, failures and recovery per record. These are development-exposed native diagnostics with no reconstruction SNR, independent-validation claim or posterior correction. Save the first mode window per trial and every correction decision.",
    "frontal-calibration-hybrid": "Project extension: unscored same-channel EEG/HEOG/VEOG calibration fits signed spatial transfer with fixed lags [-10,0,10], ridge 0.01 and trial-boundary exclusions. A pooled frontal field-association threshold 0.4 gates both arms. Fit one scoring gain, bounded [0,8], from raw frontal EEG or K3 modes whose eye association exceeds 0.2. These are declared fixed settings, not an AutoVMD search. The matched raw arm tests whether VMD adds value. Keep residual/neural signal by subtracting only the transferred field; all nonfrontal rows remain input. This method closely matches the reference-generated controlled mixture family; independent native evidence is required. No target enters calibration or scoring inference; no global neural fitting occurs.",
    "frontal-gain-unit-audit": "Retain the frozen historical K3/2000 model and four previous arms. Add two predeclared unit-adapter controls: convert verified corpus volts to microvolts consistently for EEG, EOG, modes and calibration, then divide the estimated artifact by the same factor before subtraction. Compare with and without calibration anchoring. This diagnoses the archived model's absolute 1e-6/1e-12 floors; the original Klados units remain unknown. No new fitting, AutoVMD, anatomy assignment or target-dependent scale. Score every eligible frontal row and clean control; all previous failed results remain evidence.",
    "frontal-hybrid-evidence": "Attach one completed frontal-gain-hybrid result with readiness and frontal fixture parents. Verify checksums, scope, all predeclared arms and closed confirmation access. Recompute the existing preservation review from saved paper metrics, report recipient/donor-aware approximate uncertainty, and inspect condition/input-level tables and frontal plots. No fitting, prediction changes, recipe selection or physiological claims from unknown Klados anatomy. This is a development evidence package, not final qualification.",
    "frontal-gain-hybrid": "Use the same verified frontal inputs, exact K3/2000 cache and frozen historical gain weights as the frontal transfer control. Four predeclared arms: original support, independent HEOG/VEOG support, mean anchoring to unscored calibration references, and both changes. No weight fitting, K/alpha search, target-dependent gate or posterior decomposition occurs. Mean anchoring restores only the estimated reference-projected offset, never the EEG/paired-target mean. Compare every arm with identity and the source-excluded selected direct regression on 320 development examples. Preserve all failures, clean controls and unchanged nonfrontal rows. Results require uncertainty/native evidence before any superiority or deployment claim.",
    "frontal-frozen-transfer": "Attach completed corpus, readiness, frontal fixtures, K3 cache, full correction screen and archived context checkpoint. Verify the exact checkpoint and pinned legacy model source. Apply K3 modes and aligned runtime HEOG/VEOG only on verified frontal rows; disable the anatomy feature never trained in the historical model. Keep all posterior/shared/unknown input unchanged. Compare frozen gains, source-excluded selected direct regression and identity on all development examples. No neural weights are trained, no K search occurs, and historical Klados SNR is not attributed to this transfer. Save predictions and preservation gates; native validation and qualification remain pending.",
    "frontal-cache-audit": "Read both checksum-verified K3/2000 and K4/2000 caches for all eligible development examples. Compare float32 and float64 summation under the original reconstruction tolerance. Save per-channel errors and failed checks. No decomposition, parameter selection, cache mutation, scoring or qualification occurs.",
    "frontal-evaluation": "Attach the completed full correction-screen version, readiness, passing fixture, corpus and fixed K3/K4 caches. Correction screening must declare source-balanced pilot recipients and evaluation_complete=false. Reuse each heldout bucket's immutable recipe and fitted SVM; exclude both recipient and donor from their fitting identities. Evaluate all 320 source-balanced development examples at -5/0/5 dB plus clean controls, all verified frontal channels, with no retuning or K selection. Save all selected predictions, per-example recovery shards, paper MSE/RRMSE/CC/output-SNR/improvement, clean preservation, mode diagnostics, source-aware uncertainty and failures. Native OSF is a separate next checkpoint; this stage cannot itself authorize regional integration or teacher learning.",
    "frontal-evidence": "Attach one completed calibrated-detector frontal comparison, corpus, readiness, passing fixture and exact K3/K4 caches. Use the first sorted example per condition rather than favorable examples. Reconstruct both fixed-mode representations from verified caches, save vectors/residuals and frequency-labelled waveforms. Check the reusable whole-montage interface against saved selected pilot predictions; no nonfrontal correction or new decomposition is permitted. Compare instantaneous versus declared short-lag reference projection as a diagnostic, and quantify the interval detector's coverage of true controlled artifact energy. Paired targets are evaluation-only and must never enter the estimator or support gate. The diagnostic lag bank matches corpus construction; results cannot establish native generalization or authorize a teacher. Report actual frontal input SNR separately from nominal whole-montage mixture level. Preserve all mechanism failures and review uncertainty alongside direct-regression controls.",
    "frontal-native": "Attach the passing frontal fixture, readiness, corpus, completed full frontal comparison and pinned region-aware-eog-restore/1 source supplement. Verify every development SET/FDT before processing; preserve whole-trial calibration/scoring exclusions. Reuse source-excluded family-wise frontal recipes and detector checkpoints without native retuning. Only verified frontal channels receive VMD; posterior/shared/unknown rows remain exactly original. Cache K3/K4 decompositions once per window, retain the residual and overlap-add one artifact estimate. Report unchanged publisher HEOG_lpf association for lateral and VEOG_lpf for blink/vertical, with explicit raw-reference fallback. Preserve source units; SVM amplitude uses unscored same-channel calibration SD. Save complete trials, record checkpoints, signed/absolute ordinary CC, rest RMSE, PSD, covariance and modification. There is no native reconstruction SNR. Pilot covers two records; full covers every eligible development record. Per-participant paper-based permutation is separate from engineering gates. Source-code parity and full qualification remain explicit limitations.",
    "frontal-fixture": "Synthetic software checkpoint for configs/frontal_replication.json. Numerical tests run on Kaggle. Only verified F/AF/FP channels may enter VMD. K3/alpha2000 and the fixed K4/alpha2000 comparator are permitted; AutoVMD and model stages are blocked. Check reconstruction, signed HEOG/VEOG selection, reference-event calibration, unit behavior and channel/mode permutations. No synthetic test authorizes accuracy, posterior integration or neural training.",
    "frontal-comparison": "Attach exact corpus/2, readiness/1, frontal fixture and completed K3/K4 cache versions. Import only checksum-verified fixed alpha2000 entries; do not rerun a search. All verified frontal channels are scored; posterior/shared/unknown remain untouched. Compare identity, direct regression, whole-mode, projected-mode, interval-projected and SOBI correction plus explicitly labelled 2022 selector and 2024 SVM/ApEn adaptations. The author repository lacks entropy/evaluation helpers; custom VMD initialization differs, so no author-code parity is claimed. SVM receives EEG only and fits outside heldout recipient/donor sources. It uses a declared feature subset, RBF C=1/gamma=scale, 5.12-second windows, no mRMR and no GA. References are unchanged HEOG/VEOG; target and true artifact never enter inference. Save per-channel predictions for the pilot, per-example score shards, full candidate grids, convergence failures, modes/frequency diagnostics and grouped family-wise selection. Pilot uses one recipient per source bucket; full uses the source-balanced 320-example development subset. Partial preservation and development SNR are not teacher qualification. See docs/FRONTAL_REPLICATION_PLAN.md and docs/FRONTAL_PAPER_AUDIT.md.",
    "posterior-context":"Attach pinned corpus and passing research-readiness artifacts. CPU-only classical experiment independent of the GPU frontal sweep. Compare ICA and regularized GEVD-MWF with posterior-only, common-average, signed left/right/midline/common/right-minus-left, raw frontal and full-montage support; correct posterior outputs only. Metadata determines stable support layouts; missing-context flags are saved. Both experts fit only unscored calibration, including trial-join protection for ICA reference association. Pilot: one recipient per frozen fold, clean plus 0 dB blink/lateral/mixed; MWF ranks 1/2, both declared lag banks, thresholds .4/.6 and strengths .5/1. Full: all eligible recipients, -5/0/5 dB, ranks 1..4 and all declared thresholds/strengths. Save complete per-channel paper MSE/temporal RRMSE/Pearson/output-SNR/improvement, per-example shards, convergence failures and source-excluded recipe selection. Identity and fixed .01-ridge EOG regression controls share the original input. Calibration/scoring layouts and donor/recipient disjointness are enforced. Signed virtual channels are redundant; rank/regularization effects are disclosed. Partial preservation screening does not qualify a teacher; paired-correlation comparator and native OSF validation remain separate. Read docs/POSTERIOR_CONTEXT_PLAN.md.",
    "neural-diagnosis":"Attach readiness, corpus and the completed MSE pilot outputs. Verify actual clean arrays equal their paired targets with zero added artifact, mixture closure, saved prediction identities and complete validation coverage. Compare against the exact identity control and save projection gains and correction errors. This diagnoses data and predictions; it cannot establish that a proposed loss fixes preservation.",
    "research-ready":"Attach the pinned corpus and original/restored source bundles. Verify all development source paths before trial processing, reproduce the restored study04 session and validate every paired example and source bucket. A passing readiness artifact permits paired neural research; it does not assert scientific accuracy or teacher qualification.",
    "neural-fixture":"Synthetic software contracts only: components sum to input, zero heads reproduce identity, variable channel/mode masks and permutation, no-context behavior, finite optimization and model reload. This fixture cannot establish denoising accuracy.",
    "autovmd-cache":"Attach readiness and corpus. RMS-normalized K=3..10, alpha=250/500/1000/2000/4000; retain residual and physical descriptors. Shard by explicit settings and save every numerical failure. Source-balanced search includes clean/blink/lateral/mixed and -5/0/+5dB inputs, with all verified frontal channels.",
    "autovmd-search":"Require complete source-excluded inner-fold evidence. Rank forty five-epoch candidates, eight fifteen-epoch candidates and two full-training candidates. Record rejected candidates; do not tune on outer evaluation or confirmation sources.",
    "router-train":"Width-32 shared frequency-conditioned routing with raw full-band context. Compare fixed-band, frontal-VMD/posterior-Fourier, no-context, all-VMD and raw-only arms. EEG/EOG references never enter model inference; subtract one artifact estimate from the original input. Configurations freeze across epochs.",
})


NEW_STAGES.append(("47_Regional_Integration", "regional-integration", "Compose fixed frontal corrections with inherited posterior recipes; exploratory development only."))
DETAILS["regional-integration"] = "Four immutable frontal arms (calibrated raw/VMD, ungated/monotonic temporal support) cross inherited posterior direct/ICA/MWF fold recipes and pass-through. No parameter search or neural fitting. Validate parent checksums, exact frontal input/target/channel parity, posterior OOF coverage and reproduced metrics, disjoint masks and one subtraction. Save regional/whole-cap paper metrics, participant-balanced output SNR and separate pooled-energy summaries. Native preservation remains unresolved; completion does not qualify teachers or deployment."


NEW_STAGES.append(("48_Regional_Error_Diagnostic", "regional-diagnostic", "Locate frozen regional reconstruction errors without changing methods."))
DETAILS["regional-diagnostic"] = "Attach regional-full-001/1 only; verify manifest, source, split, channel masks and required predictions. Separate frontal/posterior/central-shared/unknown error energies and coverage. Reproduce frozen-arm channel paper metrics and whole pooled SNR; full execution also reconciles archived participant-balanced means. No fitting, correction change, VMD search or neural training. Pilot precedes full diagnostic. Preserve undefined metrics and failures; save exact tables and figures. Attribution of development error is not scientific qualification."

NEW_STAGES.append(("49_Regional_Central_Coverage", "regional-coverage", "Compare four central/shared coverage policies with frozen frontal and posterior outputs."))
DETAILS["regional-coverage"] = "Attach pinned corpus/2, regional-full-001/1 and full diagnostic/1. Preserve exact source partitions and all frozen frontal/posterior waveforms. Compare central pass-through, calibration-frozen dual-reference ridge, separate HEOG/VEOG event-gated ridge, and transfer from cross-fitted fixed-K3 frontal calibration artifacts. No AutoVMD or parameter search. Calibration VMD uses at most four whole within-trial 1024 chunks, with held-out chunk fitting. Save coefficients, mode caches, failures, predictions and paper metrics. Explicitly disclose controlled EEG/EOG amplitude mismatch and limited calibration coverage. Unknown anatomy remains untouched; one original-input subtraction. Completion is exploratory and never authorizes models or confirmation."


NEW_STAGES.append(("50_Regional_Matched_Frontal_Context", "regional-context-match", "Isolate raw versus VMD frontal artifact context for central transfer."))
DETAILS["regional-context-match"] = "Attach corpus/2, regional-full/1, diagnostic-full/1 and verified central-coverage-full/1, with explicit manifest identities. Reuse every old scored output. Fit exactly one additional central raw-artifact-context arm on the identical four OOF calibration chunks and ridge policy. Frontal and posterior scored outputs remain fixed VMD/direct outputs for both context arms. Raw scoring context comes from the archived calibrated raw frontal artifact estimate, not a paired target or stored mixture amplitude. No new VMD decompositions, AutoVMD, recipe search, neural models or confirmation access. Save whole/cohort/condition/region paper metrics, preservation failures, fit availability and recipient/donor-aware project uncertainty. Identical clean outputs do not qualify native preservation."


def cell(kind, source):
    result = {"cell_type": kind, "metadata": {}, "source": source.splitlines(keepends=True)}
    if kind == "code":
        result.update(execution_count=None, outputs=[])
    return result


NEW_STAGES.append(("51_Native_Frontal_Separate_Axis_Support", "frontal-native-separate-axis", "Test fixed joint-field correction with separate HEOG/VEOG supports on native development trials."))
DETAILS["frontal-native-separate-axis"] = "Exploratory preservation repair, not a qualified teacher checkpoint. Attach corpus/2, readiness/1, unchanged frontal fixture/1, controlled monotonic/1, native monotonic/1 and restoration/1 plus raw source. Validate exact controlled/native parent manifest and source identities. Compare identity and matched raw/VMD OR versus separate-axis supports. Same joint calibration coefficients, shared scalar gain, K3/2000, thresholds, lags and current1024-window overlap-add support policy. Independent trial preprocessing; no whole-trial support-policy change. Save every window's two signed fields, references and supports, full trial predictions and paper-native suppression/rest preservation. Reproduce predecessor identity/rawOR/VMDOR trials within declared tolerance. Joint axis fields can cancel; separate support can worsen correction. Gates remain unchanged and qualification false; no neural/AutoVMD/reserved work."


NEW_STAGES.append(("52_Native_Frontal_Intervention_Diagnostic", "frontal-native-axis-diagnostic", "Explain saved native resting interventions without fitting or changing predictions."))
DETAILS["frontal-native-axis-diagnostic"] = "Attach exact separate-axis native pilot/1, readiness/1 and unchanged frontal fixture/1 only. Reconstruct all five archived outputs with saved fields and supports through identical per-trial overlap-add. Require exact original-window/reference alignment and255 full-trial output parity checks. No raw source access, VMD, fitting, search or training. Stratify rest from saved preservation reports only after reconstruction. Report shared gain, association, support, signed field cross energy/cancellation and intervention fractions. These are descriptive mechanism diagnostics; original paper/native preservation and suppression reports remain unchanged. Overlapping padded windows are not independent observations. Save original-overlap lengths and exclude zero-overlap windows from means/ranking; full-window energy fractions are not trial modification. Rank resting examples explicitly by correction fraction, not favorable performance. Preserve qualificationfalse."


NEW_STAGES.append(("53_Native_Frontal_Bounded_Feasibility", "frontal-native-bounded-feasibility", "Test twelve fixed correction settings without selecting a global native recipe."))
DETAILS["frontal-native-bounded-feasibility"] = "Attach native separate-axis/1, readiness/1 and unchanged frontal fixture/1. Replay association0.4/0.6/0.8 and multiplier0.25/0.5/0.75/1 on cached raw/VMD OR/separate fields. Forty-eight active arms plus identity;255 baseline output checks. No new VMD, fitting or training. Save every trial prediction, decisions and unchanged-gate rest preservation. Rest labels are reporting-only. Verified cached source labels enter reporting only: complete-condition HEOG lateral/VEOG blink/vertical correlations and rest RMSE with40 baseline metric parity rows; no significance/winner claim. This exposed pilot tests feasibility only; no global selection, qualification or confirmation."


NEW_STAGES.append(("54_Native_Frontal_Trial_Support", "frontal-native-trial-support", "Isolate original-trial versus per-window EOG support over fixed frontal artifact fields."))
DETAILS["frontal-native-trial-support"] = "Attach exact native separate-axis/1, corpus/2, readiness/1 and frontal review fixture/1; no raw data. Reconstruct detector only from unscored calibration; validate exact source ledgers, labels, boundaries, every cached threshold and all306local window masks before new predictions. Same fixed.4/1 policy and K3/2000 fields/gains; nine scored outputs. Compute support before padding and align original samples across windows. Require255baseline waveform checks,40condition metric rows and204reflected/zero-padding crop checks. Save complete-condition named-reference CC, rest RMSE/spectra, engineering gates and all tracks/predictions/failures. No new VMD, artifact fitting, recipe selection, training or reserved evaluation. Qualification remains false."


NEW_STAGES.append(("55_Frontal_Artifact_Shape", "frontal-artifact-shape", "Test fixed DC-preserving artifact-shape projection with unchanged VMD gain."))
DETAILS["frontal-artifact-shape"] = "Attach exact controlled monotonic/1, corpus/2, historical K3 cache/1, readiness/1 and frontal fixture/1. No raw data, neural checkpoint or new VMD. Same320development examples and archived post-gain fields; verify names, targets(for scoring), mode/residual reconstruction and original selected_modes (.2 lag association) before projection. Four outputs:identity,calibratedraw,originalVMD,DC-preserving shape. Gain/admission/lags fixed; no temporal mask. Require960baseline prediction checks and underlying metric parity. CC deterioration uses strongest calibrated raw. Preserve failed/masked/nonfrontal pass-through. Save ranks, singular values, coefficients, DC, all predictions/paper metrics/gates and source-aware uncertainty. Contaminated EEG basis is not pure ocular space. Qualification remainsfalse; no reserved or model work."
NEW_STAGES.append(("56_Frontal_Shape_Error_Diagnostic", "frontal-shape-diagnostic", "Diagnose the rejected shape correction using frozen prediction error identities."))
DETAILS["frontal-shape-diagnostic"] = "Attach shape-full/1, readiness/1 and frontal fixture/1. No raw corpus, cache, new VMD or fitting. Verify exact parent/source/manifest and all320frozen windows. Retain every verified frontal row and failure. Check DC, invalid lag edges, selected-span rank bounds,640saved prediction identities and8320channel-MSE checks. Decompose MSE change into discarded-field energy plus error/field cross term; targets are retrospective evaluation references only. Save per-channel and recipient/condition/input terms; no new correction or selection. No native/teacher/integration qualification follows."
NEW_STAGES.append(("57_Frontal_Benchmark_Source_Eligibility", "frontal-benchmark-eligibility", "Audit source eligibility before an independent frontal paired benchmark."))
DETAILS["frontal-benchmark-eligibility"] = "Metadata/provenance only; no raw dataset or kernel parents, EEG loading, VMD, fitting or model. Read the pinned source-contract register and unchanged, attributed public Ear-EEG supplement vendored in the exact Git checkout; verify its original SHA. No live publisher download. Preserve sensitivity table groups and all unresolved signs/reference/polarity fields. Every benchmark requirement must be verified before readiness. Save source matrix, exact document, blocking reasons and software-test evidence. An audit can COMPLETE with benchmark_ready=false; this is not a cleaning score or promotion. Current sources, legacy unknown anatomy, native unpaired data and reserved access remain correctly distinguished."


def build(path, stage, run_spec=None):
    spec = run_spec or {"stage": stage, "run_id": stage+"-manual", "git_sha": "", "campaign_id": "vmd-eog-20261010", "profile": "pilot"}
    setup = '''import os, sys, json, tempfile, subprocess
from pathlib import Path
IN_KAGGLE = Path('/kaggle/input').is_dir()
if not IN_KAGGLE:
    raise RuntimeError('This numerical campaign runs on Kaggle only')
TEMP_ROOT = Path(tempfile.mkdtemp(prefix='vmd-eog-'))
CHECKOUT = TEMP_ROOT / 'repository'
REPOSITORY_URL = 'https://github.com/saltypal/Lateral-eye-Artifact-removal.git'
BRANCH = 'research/vmd-eog-removal-notebooks'
''' + 'RUN_SPEC = ' + repr(spec) + '''
OUT = Path('/kaggle/working/results') / RUN_SPEC['campaign_id'] / RUN_SPEC['run_id']
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'run_spec.json').write_text(json.dumps(RUN_SPEC,indent=2))
(OUT/'experiment.json').write_text(json.dumps(RUN_SPEC.get('experiment',{}),indent=2))
(OUT/'execution_state.json').write_text(json.dumps({'stage':RUN_SPEC['stage'],'status':'bootstrap_running'}))
print('BOOTSTRAP_START', RUN_SPEC['run_id'], RUN_SPEC['git_sha'], flush=True)
def bootstrap_call(command, phase):
    print('BOOTSTRAP_PHASE', RUN_SPEC['run_id'], phase, flush=True)
    result = subprocess.run(command)
    if result.returncode:
        (OUT/'execution_state.json').write_text(json.dumps({'stage':RUN_SPEC['stage'],
            'status':'failed','failure_layer':'bootstrap','phase':phase,'exit_code':result.returncode}))
        raise RuntimeError('Bootstrap failed during '+phase+'; retained run identity and status in '+str(OUT))
# Manual launches resolve latest once; CLI launches already have its exact SHA.
if not RUN_SPEC['git_sha']:
    line = subprocess.check_output(['git','ls-remote',REPOSITORY_URL,'refs/heads/'+BRANCH], text=True).strip()
    RUN_SPEC['git_sha'] = line.split()[0]
bootstrap_call(['git','clone','--quiet','--branch',BRANCH,'--single-branch',REPOSITORY_URL,str(CHECKOUT)], 'clone')
bootstrap_call(['git','-C',str(CHECKOUT),'checkout','--quiet',RUN_SPEC['git_sha']], 'checkout')
ACTUAL_SHA = subprocess.check_output(['git','-C',str(CHECKOUT),'rev-parse','HEAD'],text=True).strip()
if ACTUAL_SHA != RUN_SPEC['git_sha']:
    raise RuntimeError('Source SHA mismatch')
ENV_ROOT = TEMP_ROOT / 'environment'
bootstrap_call([sys.executable,'-m','venv','--without-pip','--system-site-packages',str(ENV_ROOT)], 'environment')
ENV_PY = ENV_ROOT / 'bin/python'
bootstrap_call([sys.executable,'-m','pip','--python',str(ENV_PY),'install','--quiet','--progress-bar','off','-r',str(CHECKOUT/'requirements.txt')], 'dependencies')
PROCESS_ENV = os.environ.copy()
PROCESS_ENV['PYTHONPATH'] = str(CHECKOUT/'src')
PROCESS_ENV['PYTHONUNBUFFERED'] = '1'
PROCESS_ENV['OMP_NUM_THREADS'] = '2'
(OUT/'run_spec.json').write_text(json.dumps(RUN_SPEC,indent=2))
(OUT/'experiment.json').write_text(json.dumps(RUN_SPEC.get('experiment',{}),indent=2))
print('Exact Git SHA:', ACTUAL_SHA, 'Stage:', RUN_SPEC['stage'], 'Output:',OUT,flush=True)
'''
    execute = '''command = [str(ENV_PY),'-m','vmd_eog.runner','--stage',RUN_SPEC['stage'],
           '--input','/kaggle/input','--output',str(OUT),'--profile',RUN_SPEC['profile'],
           '--config',RUN_SPEC.get('config_path','configs/campaign.json'),
           '--experiment',str(OUT/'experiment.json')]
process = subprocess.run(command,cwd=CHECKOUT,env=PROCESS_ENV)
if process.returncode:
    raise RuntimeError('Stage failed; inspect saved execution_state.json and kernel logs')
print((OUT/'execution_state.json').read_text())
'''
    inspect = '''from IPython.display import display, Image
for figure in sorted(OUT.glob('*.png')):
    display(Image(filename=str(figure)))
for report in sorted(OUT.glob('*summary.json')):
    print(report.name, report.read_text()[:16000])
print('Persist this completed kernel version and retrieve outputs before launching a dependent stage.')
'''
    inspect_modules = '''CONFIGURATION = json.loads((CHECKOUT/RUN_SPEC.get('config_path','configs/campaign.json')).read_text())
print('Declared signal contract:', {key: CONFIGURATION[key] for key in ('fs','window','hop','seed')})
print('Preservation limits:', CONFIGURATION['preservation'])
if CONFIGURATION.get('schema_version') == 4:
    if RUN_SPEC['stage'] == 'regional-context-match':
        print('Modules: regional_context_match.py, calibration_frontal_context.py, coverage_uncertainty.py')
        print((CHECKOUT/'docs/MATCHED_CONTEXT_PLAN.md').read_text())
    elif RUN_SPEC['stage'] == 'regional-coverage':
        print('Modules: regional_coverage.py, nonfrontal_ridge.py, calibration_frontal_context.py')
        print((CHECKOUT/'docs/CENTRAL_COVERAGE_PLAN.md').read_text())
    elif RUN_SPEC['stage'] == 'regional-diagnostic':
        print('Modules: regional_diagnostic.py, paper_metrics.py, artifacts.py')
        print((CHECKOUT/'docs/REGIONAL_NEXT_STEPS_20261013.md').read_text())
    else:
        print('Modules: regional_integration.py, posterior_context.py, artifacts.py')
        print((CHECKOUT/'docs/REGIONAL_INTEGRATION_PLAN.md').read_text())
    print('Frontal VMD only; stopped AutoVMD; no model or confirmation qualification')
elif CONFIGURATION.get('schema_version') == 3:
    print('Modules: frontal_campaign.py -> frontal_methods.py -> frontal_replication.py/frontal_native.py')
    print((CHECKOUT/'docs/FRONTAL_PAPER_AUDIT.md').read_text())
    if RUN_SPEC['stage'] == 'frontal-native-separate-axis':
        print((CHECKOUT/'docs/FRONTAL_PRESERVATION_REPAIR_PLAN.md').read_text())
        # Read pinned source without importing into the host notebook kernel.
        # Numerical imports and execution belong to the isolated runner environment.
        print((CHECKOUT/'src/vmd_eog/frontal_event_support.py').read_text())
    if RUN_SPEC['stage'] == 'frontal-artifact-shape':
        print((CHECKOUT/'docs/FRONTAL_ARTIFACT_SHAPE_PLAN.md').read_text())
        print((CHECKOUT/'src/vmd_eog/frontal_artifact_shape.py').read_text())
    if RUN_SPEC['stage'] == 'frontal-shape-diagnostic':
        print((CHECKOUT/'docs/FRONTAL_SHAPE_DIAGNOSTIC_PLAN.md').read_text())
        print((CHECKOUT/'src/vmd_eog/frontal_shape_diagnostic.py').read_text())
    if RUN_SPEC['stage'] == 'frontal-benchmark-eligibility':
        print((CHECKOUT/'docs/FRONTAL_BENCHMARK_ELIGIBILITY_PLAN.md').read_text())
        print((CHECKOUT/'src/vmd_eog/frontal_benchmark_eligibility.py').read_text())
    if RUN_SPEC['stage'] == 'frontal-native-trial-support':
        print((CHECKOUT/'docs/FRONTAL_TRIAL_SUPPORT_PLAN.md').read_text())
        print((CHECKOUT/'src/vmd_eog/frontal_trial_support.py').read_text())
    if RUN_SPEC['stage'] == 'frontal-native-bounded-feasibility':
        print((CHECKOUT/'docs/FRONTAL_BOUNDED_FEASIBILITY_PLAN.md').read_text())
        print((CHECKOUT/'src/vmd_eog/frontal_bounded_feasibility.py').read_text())
    if RUN_SPEC['stage'] == 'frontal-native-axis-diagnostic':
        print((CHECKOUT/'docs/NATIVE_SEPARATE_AXIS_RESULTS.md').read_text())
        print((CHECKOUT/'src/vmd_eog/frontal_axis_diagnostic.py').read_text())
    print('Scope: verified frontal only; AutoVMD stopped; posterior unchanged')
else:
    print('Algorithm explanation: docs/SCIENTIFIC_EXPLANATION.md in the pinned checkout')
    print('Modules: signal.py -> reference.py/frontal.py/posterior.py -> experiments.py -> review evidence')
print('Git source:', ACTUAL_SHA)
'''
    tables = '''import csv
from itertools import islice
for name in ('regional_method_means.csv','regional_condition_means.csv','posterior_oof_review.csv','vmd_search.csv','posterior_search.csv','review_methods.csv','condition_source_uncertainty.csv','paper_metric_fixture.csv','paper_paired_channels.csv','paper_native_channels.csv','paper_rest_bandpower_channels.csv','paper_paired_source_means.csv','paper_native_source_means.csv','paper_paired_permutation_tests.csv','paper_native_permutation_tests.csv','native_condition_channels.csv','native_condition_participants.csv','native_condition_permutations.csv','vmd_diagnosis_method_means.csv','vmd_diagnosis_clean_preservation.csv','vmd_mode_projection_diagnostics.csv','paper_plot_participant_conditions.csv','vmd_sobi_method_means.csv','vmd_sobi_clean_preservation.csv'):
    path = OUT/name
    if path.exists():
        print(name, '(first 8 saved rows; complete table remains in outputs)')
        with path.open() as handle:
            display(list(islice(csv.DictReader(handle),8)))
for name in ('posterior_context_search.csv','posterior_context_oof_scores.csv'):
    path = OUT/name
    if path.exists():
        print(name, '(first 8 rows; complete paper metrics and failure records saved)')
        with path.open() as handle:
            display(list(islice(csv.DictReader(handle),8)))
for name in ('frontal_search.csv','frontal_oof_means.csv','frontal_oof_recipients.csv',
             'native_frontal_preservation_records.csv','native_frontal_preservation_participants.csv',
             'frontal_mechanism_diagnostics.csv','frontal_oof_conditions.csv','frontal_clean_preservation.csv'):
    path = OUT/name
    if path.exists():
        print(name, '(first 12 rows; complete table saved)')
        with path.open() as handle:
            display(list(islice(csv.DictReader(handle),12)))
for name in ('selected_frontal.json','selected_posterior.json','classical_gate.json','paper_evaluation_protocol.json','paper_metric_fixture_summary.json'):
    if (OUT/name).exists():
        print(name, (OUT/name).read_text()[:8000])
if (OUT/'frontal_controlled_gates.json').exists():
    print('Controlled engineering gates:', (OUT/'frontal_controlled_gates.json').read_text())
if (OUT/'frontal_controlled_review.md').exists():
    from IPython.display import Markdown
    display(Markdown((OUT/'frontal_controlled_review.md').read_text()))
review = OUT/'APPROACH_REVIEW.md'
if review.exists():
    from IPython.display import Markdown
    display(Markdown(review.read_text()))
'''
    descriptions = {item[1]: item[2] for item in STAGES+NEW_STAGES}
    if stage in ('regional-coverage', 'regional-context-match'):
        tables = '''from IPython.display import display
import pandas as pd
for name in ('coverage_method_means.csv', 'coverage_condition_means.csv', 'coverage_uncertainty_intervals.csv', 'coverage_example_scores.csv'):
    path = OUT/name
    if path.exists():
        print(name, '(first 20 rows; complete table saved)')
        display(pd.read_csv(path).head(20))
if (OUT/'coverage_controlled_gates.json').exists():
    print((OUT/'coverage_controlled_gates.json').read_text())
'''
    if stage == 'regional-diagnostic':
        tables = '''from IPython.display import display
import pandas as pd
for name in ('diagnostic_group_means.csv', 'diagnostic_energy_means.csv', 'diagnostic_global_pooled_energies.csv'):
    path = OUT/name
    if path.exists():
        print(name, '(first 20 rows; complete table saved)')
        display(pd.read_csv(path).head(20))
'''
    if stage == 'frontal-native-bounded-feasibility':
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'bounded_native_summary.json').read_text())
gates = json.loads((OUT/'bounded_native_gates.json').read_text())
display(pd.DataFrame([{'method':row['method'], **row['worst_record'], 'preservation_pass':row['native_preservation_gates_pass']} for row in gates]))
display(pd.read_csv(OUT/'bounded_native_rest_records.csv').head(12))
print('Full exploratory trial correlations and predictions remain in saved outputs.')
'''
    if stage == 'frontal-native-trial-support':
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'trial_support_summary.json').read_text())
gates = json.loads((OUT/'trial_support_gates.json').read_text())
display(pd.DataFrame([{'method':row['method'], **row['worst_record'], 'preservation_pass':row['native_preservation_gates_pass']} for row in gates]))
display(pd.read_csv(OUT/'native_condition_participants.csv').head(18))
print('Full suppression, rest spectra, support tracks and prediction files remain saved.')
'''
    if stage == 'frontal-artifact-shape':
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'shape_summary.json').read_text())
print((OUT/'shape_controlled_gates.json').read_text())
display(pd.read_csv(OUT/'shape_method_means.csv'))
display(pd.read_csv(OUT/'shape_condition_means.csv'))
display(pd.read_csv(OUT/'coverage_uncertainty_intervals.csv'))
'''
    if stage == 'frontal-shape-diagnostic':
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'shape_error_summary.json').read_text())
display(pd.read_csv(OUT/'shape_error_balanced_terms.csv'))
display(pd.read_csv(OUT/'shape_error_condition_terms.csv'))
'''
    if stage == 'frontal-benchmark-eligibility':
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'benchmark_eligibility_summary.json').read_text())
sources = pd.read_csv(OUT/'benchmark_eligibility.csv')
display(sources[['id', 'role', 'paired_target', 'frontal_mapping', 'independent_generator', 'eligible']])
display(sources[['id', 'limitations']])
print((OUT/'published_sensitivity_table.json').read_text())
'''
    if stage in ('nonfrontal-challengers', 'nonfrontal-mwf-controls', 'nonfrontal-cca'):
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'nonfrontal_summary.json').read_text())
means = pd.read_csv(OUT/'nonfrontal_method_means.csv')
display(means[means.scope.isin(['whole','posterior','central_shared'])])
display(pd.read_csv(OUT/'nonfrontal_condition_means.csv'))
print((OUT/'nonfrontal_controlled_gates.json').read_text())
display(pd.read_csv(OUT/'coverage_uncertainty_intervals.csv'))
'''
        inspect_modules = '''CONFIGURATION = json.loads((CHECKOUT/RUN_SPEC['config_path']).read_text())
print((CHECKOUT/'docs/NONFRONTAL_CHALLENGERS_PLAN.md').read_text())
print('Fixed policy:', CONFIGURATION['challenger_policy'])
print('Inspectable modules: nonfrontal_challengers.py and nonfrontal_experiment.py')
print('Frontal outputs frozen; no posterior/central VMD; no AutoVMD or model training.')
'''
        DETAILS[stage] = 'Fixed-recipe posterior and central component-correction adaptations. Pin corpus002 and matched-context-full001. Match full-montage calibration support, preserve frontal outputs and score separate region changes plus their composition. No clean target enters fitting or correction. Save all predictions, component fits, per-record progress, paper metrics and failure rows. Pilot precedes full development evaluation; native and independent qualification remain separate.'
        if stage == 'nonfrontal-mwf-controls':
            DETAILS[stage] = 'Two fixed GEVD-MWF controls, rank1/rank2 with instantaneous full-montage support and strength1. Reuse the validated posterior solver but output only posterior/central rows. Same field-association gate, parents, scoring cohort and frozen frontal VMD output as notebook58. No repeated posterior grid, target fitting or teacher promotion.'
        if stage == 'nonfrontal-cca':
            tables += '''display(pd.read_csv(OUT/'cca_pooled_method_means.csv'))
display(pd.read_csv(OUT/'matched_cca_controls/coverage_uncertainty_intervals.csv'))
print((OUT/'cca_coupling_audit.json').read_text())
'''
            DETAILS[stage] = 'Six fixed calibration-only CCA/control mechanisms: direct joint ridge, previous rest-whitened reference-rank2, rank1/rank2 canonical reference-direction truncation, and rank1/rank2 EEG-source backprojection. Same lag bank, calibration/scoring separation, original-input field gate and frozen frontal VMD outputs. Regularization0.01 and actual calibration Pearson squared admission0.16 are project adaptations, not published optima. Reference full-basis identity and matched ridge parity must pass; saved fits replay bit-for-bit. Report middle/temporal subgroups, paper metrics, conditions, gate failures, uncertainty and preservation. Known synthetic reference coupling mismatch remains disclosed; no fresh/native qualification or models. See NONFRONTAL_CCA_PLAN.md.'
            inspect_modules = '''CONFIGURATION = json.loads((CHECKOUT/RUN_SPEC['config_path']).read_text())
print((CHECKOUT/'docs/NONFRONTAL_CCA_PLAN.md').read_text())
print('Inspectable modules: nonfrontal_cca.py and nonfrontal_experiment.py')
print('Known legacy coupling limitation; no repaired-corpus or author-parity claim.')
'''
    if stage == 'nonfrontal-review':
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'frontend_review_summary.json').read_text())
display(pd.read_csv(OUT/'review_method_means.csv'))
display(pd.read_csv(OUT/'review_condition_means.csv'))
print((OUT/'review_gates.json').read_text())
display(pd.read_csv(OUT/'coverage_uncertainty_intervals.csv'))
'''
        inspect_modules = '''print((CHECKOUT/'docs/NONFRONTAL_CHALLENGERS_PLAN.md').read_text())
print('Frozen predictions only; no fitting or parameter selection.')
print('Channel-first and pooled-energy SNR are separate aggregations.')
print('Module: nonfrontal_review.py; two disjoint fields, one subtraction.')
'''
        DETAILS[stage] = 'Attach the exact completed nonfrontal parent and matched-context-full001/1 specified by configuration. Verify source/split identities and every consumed prediction. Hold nonfrontal outputs fixed and replace only frontal rows with archived calibrated raw regression; retain the matched VMD output. Recipes are limited to the archived rank2/ICA review or the new complete-ridge/CCA-rank2/reference-rank2 comparison. Report verified middle versus temporal subgroups, paper metrics, preservation, matched frontend supplemental uncertainty and both channel-first and pooled-window SNR. No new fit, neural model, AutoVMD, reserved data or native qualification.'
    if stage == 'nonfrontal-gain-diagnostic':
        tables = '''import pandas as pd
from IPython.display import display
print((OUT/'gain_summary.json').read_text())
display(pd.read_csv(OUT/'gain_method_means.csv'))
display(pd.read_csv(OUT/'gain_condition_means.csv'))
print((OUT/'gain_gates.json').read_text())
display(pd.read_csv(OUT/'coverage_uncertainty_intervals.csv'))
print('Evaluator-only target-fitted bounds are diagnostic and cannot be used at inference.')
display(pd.read_csv(OUT/'evaluator_only_gain_bounds.csv').head(12))
'''
        inspect_modules = '''print((CHECKOUT/'docs/NONFRONTAL_GAIN_DIAGNOSIS_PLAN.md').read_text())
print('Module: nonfrontal_gain_diagnostic.py')
print('Fixed strengths/blends use saved fields only; no target or condition enters correction.')
'''
        DETAILS[stage] = 'Attach exact completed nonfrontal-full001/1 only. Hold frontal K3/2000 outputs bit-for-bit. Compare fixed0.25/0.5/0.75 strength on saved nonfrontal rank2 fields and convex blends with the old VMD-context nonfrontal fields. Four archived controls remain unchanged. These weights are predeclared and not fitted or selected from scoring targets. Only after predictions exist, calculate explicitly nondeployable scalar/blend oracle bounds and close mean-bias/centered-error energy accounting. Save every prediction, per-example progress, paper metrics, channel-first/pooled SNR, condition/subgroup results, conservative historical failure flags and preservation gates. Pilot precedes full cohort. No new VMD, calibration, neural weights or reserved access.'
    if stage == 'reference-coupling-audit':
        tables = '''print((OUT/'source_probe_summary.json').read_text())
print((OUT/'source_probe_selection.jsonl').read_text())
print((OUT/'source_probe_completed.jsonl').read_text())
print('Original sources recovered; coupling repair and accuracy qualification remain pending.')
'''
        inspect_modules = '''print((CHECKOUT/'docs/NEXT_REGIONAL_VALIDATION_PLAN.md').read_text())
print('Modules: reference_coupling_audit.py and checksummed prepare_lemon in corpus.py.')
print('Original recipient calibration is reacquired; mixed calibration is never unmixed.')
'''
        DETAILS[stage] = 'Attach exact corpus002/2 and CCAfull001/1. Source-only selection of two development pairs with distinct donors. Verify original recipient archive/header hashes before numerical loading; recover the unscored prefix and original donor calibration with explicit units/axes/trial identities. All tests run before source processing. Save each completed pair and progress. No new mixture, solver, training, reserved access or qualification. This is prerequisite source recovery for separately versioned coupling repair.'
    if stage == 'coupled-pilot':
        tables = "print((OUT/'coupled_pilot_summary.json').read_text())\nprint((OUT/'producer_diagnostics.json').read_text())\n"
        inspect_modules = "print((CHECKOUT/'src/vmd_eog/coupled_pilot.py').read_text())\nprint('Producer truth is not a denoiser input. No accuracy qualification in this notebook.')\n"
        DETAILS[stage] = 'Twenty-record engineering pilot from two frozen development recipient/donor pairs. Verify source and corpus manifests, recover chronological scoring windows and complete unscored calibration trials. Use one shared multiplier for homogeneous injected ocular fields and HEOG/VEOG excursions. Save observed calibration separately from producer-only background and field truth. Preserve source units, trial boundaries, regional input SNR and hashes. No VMD, neural training, reserved access or teacher qualification. Follow with newly hashed fixed frontal K3/2000 decompositions only after full recovery.'
    if stage == 'coupled-frontal-review':
        tables = "print((OUT/'coupled_frontal_summary.json').read_text())\nprint((OUT/'method_means.csv').read_text())\n"
        inspect_modules = "print((CHECKOUT/'src/vmd_eog/coupled_frontal_review.py').read_text())\nprint('Fixed K3/2000, frontal only. Five matched arms; no automatic parameter selection.')\n"
        DETAILS[stage] = 'Attach only the checksummed completed coupled pilot. Run numerical tests before new frontal-only K3/2000 decompositions. Compare identity and calibrated raw/VMD frontal correction, each with nonfrontal pass-through or identical full ridge. Save all modes/residuals, centers, convergence, input hashes, fits, decisions and predictions. Targets become available to scoring only after predictions are fixed. Separate channel-first and pooled SNR, all ocular conditions, clean controls and regional preservation. Two development pairs establish engineering behavior only; no native, fresh confirmation, teacher qualification or student authorization.'
    if stage == 'lateral-gain-review':
        tables = "print((OUT/'lateral_gain_summary.json').read_text())\nprint((OUT/'method_means.csv').read_text())\nprint((OUT/'condition_means.csv').read_text())\n"
        inspect_modules = "print((CHECKOUT/'docs/LATERAL_REPAIR_REVIEW_20261015.md').read_text())\nprint('Modules: lateral_gain_review.py and frontal_calibration_transfer.py. No target or condition label enters inference.')\n"
        DETAILS[stage] = 'Literature-informed lateral repair using fixed archived K3/2000 frontal modes. Verify exact completed corpus and review parents, input hashes and stored reconstruction. Freeze nonfrontal predictions. Eight predeclared arms: archived identity/raw-shared/VMD-shared, matched-subspace VMD scalar, raw separate-axis, matched-subspace VMD separate-axis, reference-supported residual completion and raw-anchored VMD with fixed weight0.25. Earlier projection failures remain visible. Calibration fits signed HEOG/VEOG fields; scoring estimates bounded gains without paired targets or condition labels. Run contracts first. Save all predictions, residual/reference diagnostics, gains, paper metrics, both SNR summaries, condition tables, preservation failures and plots. Two development pairs cannot qualify a teacher; no new VMD, AutoVMD, students or reserved access.'
    if stage == 'broader-source-recovery':
        tables = "print((OUT/'broader_source_summary.json').read_text())\nprint((OUT/'source_recovery_failures.json').read_text())\nprint('Audit completion does not imply all sources were recovered; corpus eligibility requires all_sources_recovered=true.')\n"
        inspect_modules = "print((CHECKOUT/'docs/BROADER_ANCHORED_VALIDATION_PLAN.md').read_text())\nprint('Modules: broader_source_recovery.py and reference_coupling_audit.py. No metrics or targets select source membership.')\n"
        DETAILS[stage] = 'Recover one immutable sixteen-recipient shard of the frozen 32-recipient, five-donor development cohort. Verify exact corpus/selection/two-pair recovery parents and cohort identity. Reuse byte-verified original prefixes where identical; reacquire other original archives/headers and preserve filtering, units, trial boundaries and source identities. Never reconstruct background from mixed calibration. Save each success and unavailable source. A completed availability audit can have all_sources_recovered=false, blocking corpus construction. No mixtures, VMD, parameter tuning, models, reserved access or qualification. Two shards are disjoint and their union must match the frozen cohort before downstream processing.'
    if stage == 'broader-coupled-corpus':
        tables = "print((OUT/'broader_corpus_summary.json').read_text())\nprint((OUT/'producer_diagnostics.json').read_text())\n"
        inspect_modules = "print((CHECKOUT/'docs/BROADER_ANCHORED_VALIDATION_PLAN.md').read_text())\nprint('Modules: broader_coupled_corpus.py and coupled_pilot.build_pair. Producer truth never enters denoiser interfaces.')\n"
        DETAILS[stage] = 'Require both exact versioned original-source shards, every frozen source recovered and the complete 32-recipient/five-donor cohort. Preserve original calibration/scoring and whole-trial boundaries. Construct ten fixed conditions per pair with homogeneous shared EOG/artifact scaling. Save all source identities, regional input SNR, hashes and pilot exposure. Regression-generated fields and low-ocular reference limitations remain. No VMD, tuning, models, reserved access or qualification. The numerical test suite runs before generation.'
    if stage == 'broader-frontal-review':
        tables = "print((OUT/'broader_frontal_summary.json').read_text())\nprint((OUT/'condition_means.csv').read_text())\nprint((OUT/'preservation_summary.json').read_text())\n"
        inspect_modules = "print((CHECKOUT/'docs/BROADER_ANCHORED_VALIDATION_PLAN.md').read_text())\nprint('Module: broader_frontal_review.py. Five frozen arms, K3/2000 frontal only, anchored weight0.25. No parameter selection.')\n"
        DETAILS[stage] = 'Require the complete repaired 320-record development corpus and exact source cohort/split identities. Compare identity, raw shared gain, raw separate-axis gain, original VMD gain and fixed raw-anchored VMD gain. Compute posterior/middle correction once and match it across correction arms; subtract disjoint original-input fields once. Save every frontal mode/residual, cache input hash, fit, decision, failure and prediction. Score all conditions and regions with paper metrics, channel-first/pooled SNR, recipient/donor/fold/exposure tables and separately labelled source-aware supplemental uncertainty. Idealized clean controls do not replace native resting validation. No AutoVMD, tuning, neural training, reserved access or teacher qualification.'
    if stage == 'broader-cached-review':
        tables = "print((OUT/'cached_review_summary.json').read_text())\nprint((OUT/'condition_means.csv').read_text())\nprint((OUT/'cc_source_limit_diagnostics.csv').read_text())\n"
        inspect_modules = "print((CHECKOUT/'src/vmd_eog/broader_cached_review.py').read_text())\nprint('Original five arms preserved. New raw fallback acts only on failed verified frontal decomposition rows. No paired target enters that choice.')\n"
        DETAILS[stage] = 'Attach exact completed 320-example corpus and five-arm comparison. Correct null-versus-Boolean failure-reporting semantics, re-score and reproduce all original paper metrics and uncertainty values within strict serialization tolerance. Retain per-record correlation screens and add explicit recipient/donor mean diagnostics; no acceptance threshold changes or teacher promotion. Test one new solver-failure-only raw fallback using cached predictions and mode flags, preserving all other rows bit-for-bit. Run numerical contracts first. No new VMD, calibration fit, parameter search, neural learning or reserved access. Save new fallback predictions, failure decisions, source checks and all matched metric tables.'
    if stage == 'artifact-bundle':
        tables = "print((OUT/'bundle_summary.json').read_text())\nprint((OUT/'bundle_index.json').read_text())\n"
        inspect_modules = "print((CHECKOUT/'src/vmd_eog/artifact_bundle.py').read_text())\nprint('Byte-preserving recovery only; no new EEG correction, metrics, VMD or training.')\n"
        DETAILS[stage] = 'Pin the completed broader frontal comparison and verify every original parent payload before tests. Package original bytes into bounded ZIP_STORED shards, retaining source run/SHA/manifest, all per-file hashes and control files. This reduces individual transfer count after CDN failures. Save bundle index, shard checksums and source manifest. Local restoration validates every archive path and original file hash before creating a complete recovery receipt. This is artifact recovery, not a new numerical result or teacher qualification.'
    if stage == 'native-cached-frontal':
        tables = "import pandas as pd\nprint((OUT/'native_cached_frontal_summary.json').read_text())\nprint((OUT/'native_frontal_preservation_gates.json').read_text())\ndisplay(pd.read_csv(OUT/'native_condition_participants.csv'))\n"
        inspect_modules = "print((CHECKOUT/'docs/NATIVE_FROZEN_FRONTAL_PLAN_20261015.md').read_text())\nprint((CHECKOUT/'src/vmd_eog/native_cached_frontal.py').read_text())\n"
        DETAILS[stage] = 'Exploratory two-record native OSF diagnostic. Pin original corpus002 calibration and native-repaired002 original full trials. Verify all parent bytes, exact source ledgers, split, sampling/window/hop, channel metadata, original identity and both reference arrays. Reuse original independently filtered trials without filtering again. Use all scoring trials of the first two record IDs; labels enter reporting only. Compare identity/raw shared/fixed K3-2000 VMD shared/0.25 raw-anchored VMD/solver-failure raw fallback, frontal only. Pass all posterior/middle/unknown channels bit-for-bit. Save every mode/residual, decision and complete trial prediction. Report unchanged publisher HEOG/VEOG condition correlations, resting RMSE/spectra and unchanged engineering gates. No native reconstruction SNR, parameter selection, neural training or teacher qualification.'
    if stage == 'native-visual-audit':
        inspect = "from IPython.display import display, Image, Markdown\nfor entry in json.loads((OUT/'figure_inventory.json').read_text()):\n    display(Markdown('### '+entry['figure']+'\\n'+entry['caption']))\n    display(Image(filename=str(OUT/'figures'/(entry['figure']+'.png'))))\n"
        tables = "print((OUT/'native_visual_summary.json').read_text())\nprint((OUT/'figure_inventory.json').read_text())\n"
        inspect_modules = "print((CHECKOUT/'src/vmd_eog/native_visual_audit.py').read_text())\n"
        DETAILS[stage] = 'Visualization and cached mode audit only. Pin completed native-frozen-frontal001/1; hash every parent payload before tests. Render nine diagnostic figures as PNG/PDF/SVG: lateral/blink/vertical correlations, resting modification/alpha/beta/covariance, resting PSD and mode-reference heatmap. Save full per-mode zero-lag and signed peak-lag HEOG/VEOG correlations plus peak lags for all12852 cached modes; replay every saved selection including failure exclusions. Labels and reference windows retain original semantics. Two development participants cannot establish population superiority. No new VMD, fitting, prediction changes, teacher qualification or reserved access.'
    detail = DETAILS[stage]
    if spec.get('campaign_id','').startswith('vmd-bandroute') and stage == 'student-paired':
        detail = 'Requires verified research readiness. Paired-only EEG TCN-BiGRU, input-derived scaling, signed metadata context, zero correction heads and no runtime EOG/VMD. Classical accuracy gates do not prevent paired learning.'
    notebook = {"nbformat":4,"nbformat_minor":5,"metadata":{"kernelspec":{"display_name":"Python 3","language":"python","name":"python3"}},
        "cells":[cell("markdown", "# Regional VMD EOG removal â€” "+stage+"\n\n"+descriptions.get(stage,stage)),
                 cell("markdown", "## Scientific question, inputs and contracts\n\n"+detail),
                 cell("markdown", "## Fresh source and environment\nResolve latest published code once and pin it. New temporary clones avoid stale Python imports; original inputs remain immutable."),
                 cell("code",setup),
                 cell("markdown", "## Inspect the pinned algorithm contract\nThe source modules remain inspectable in this checkout. Mode vectors, references and paired targets have distinct roles; the accompanying explanation defines their shapes and inference boundaries."),
                 cell("code",inspect_modules),
                 cell("markdown", "## Execute reusable modules\nHEOG/VEOG are teacher/evaluation information. Clean targets cannot enter inference. Failed numerical or scientific gates stop dependent work."),
                 cell("code",execute),
                 cell("markdown", "## Saved configurations and result tables\nThese are immutable outputs from this run. Readiness, teacher eligibility and final scientific qualification are distinct decisions."),
                 cell("code",tables),
                 cell("markdown", "## Inspect evidence and persist outputs\nNative real EEG has no clean-reference SNR. Pass-through failures remain counted. Parameters and physiological frequency bands are distinct."),
                 cell("code",inspect)]}
    for index, item in enumerate(notebook["cells"]):
        item["id"] = f"cell-{index}"
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(notebook,indent=2),encoding="utf-8")


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    for name, stage, _ in STAGES:
        build(root/"notebooks"/(name+".ipynb"),stage)
    print("Authored",len(STAGES),"notebook workflows; no numerical execution.")
